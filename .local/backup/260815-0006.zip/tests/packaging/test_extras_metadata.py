"""Packaging contracts for optional extras (metadata-only; no heavy installs)."""

from __future__ import annotations

import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
PYPROJECT = ROOT / "pyproject.toml"


def _parse_optional_extra(name: str) -> list[str]:
    text = PYPROJECT.read_text(encoding="utf-8")
    # Match [project.optional-dependencies] block for `name = [ ... ]`
    pattern = rf"(?ms)^{re.escape(name)}\s*=\s*\[(.*?)\]"
    # Prefer scanning after optional-dependencies header
    opt_idx = text.find("[project.optional-dependencies]")
    assert opt_idx >= 0
    section = text[opt_idx:]
    match = re.search(pattern, section)
    assert match, f"extra {name!r} not found in pyproject.toml"
    body = match.group(1)
    reqs = []
    for line in body.splitlines():
        line = line.strip().strip(",").strip()
        if not line or line.startswith("#"):
            continue
        reqs.append(line.strip('"').strip("'"))
    return reqs


def _normalize_req(req: str) -> str:
    # Drop environment markers; keep name+specifier for subset compare.
    return req.split(";")[0].strip()


@pytest.mark.unit
def test_bertopic_extra_is_subset_of_full() -> None:
    bertopic = {_normalize_req(r) for r in _parse_optional_extra("bertopic")}
    full = {_normalize_req(r) for r in _parse_optional_extra("full")}
    missing = bertopic - full
    assert not missing, f"bertopic extra deps missing from full: {sorted(missing)}"


@pytest.mark.unit
def test_keyphrases_extra_is_subset_of_full() -> None:
    keyphrases = {_normalize_req(r) for r in _parse_optional_extra("keyphrases")}
    full = {_normalize_req(r) for r in _parse_optional_extra("full")}
    missing = keyphrases - full
    assert not missing, f"keyphrases extra deps missing from full: {sorted(missing)}"


@pytest.mark.unit
def test_web_extra_owns_streamlit_not_full() -> None:
    """GUI Streamlit lives in [web]; [full] remains analysis extras only."""
    web = _parse_optional_extra("web")
    assert any(r.startswith("streamlit") for r in web)
    full_joined = " ".join(_parse_optional_extra("full")).lower()
    assert "streamlit" not in full_joined


@pytest.mark.unit
def test_requirements_include_keyphrases_optional_stack() -> None:
    req = (ROOT / "requirements.txt").read_text(encoding="utf-8").lower()
    assert "yake" in req
    assert "keybert" in req
    assert "streamlit" in req


@pytest.mark.unit
def test_bertopic_extra_owns_stack() -> None:
    """``[bertopic]`` owns bertopic/hdbscan/umap-learn (not base)."""
    reqs = _parse_optional_extra("bertopic")
    joined = " ".join(reqs).lower()
    for forbidden in (
        "scikit-learn",
        "numpy",
        "scipy",
        "torch",
        "transformers",
        "sentence-transformers",
    ):
        assert forbidden not in joined, f"bertopic extra must not pin {forbidden}"
    assert any(r.startswith("bertopic") for r in reqs)
    assert any(r.startswith("hdbscan") for r in reqs)
    assert any(r.startswith("umap-learn") for r in reqs)


@pytest.mark.unit
def test_sentence_transformers_owned_by_base() -> None:
    text = PYPROJECT.read_text(encoding="utf-8")
    deps_match = re.search(
        r"(?ms)^dependencies\s*=\s*\[(.*?)\]\s*\n\n\[project",
        text,
    )
    assert deps_match, "base dependencies block not found"
    body = deps_match.group(1).lower()
    assert "sentence-transformers" in body


@pytest.mark.unit
def test_bertopic_stack_not_in_base() -> None:
    """BERTopic stack lives in [bertopic]/[full], not base (llvmlite/umap gate)."""
    text = PYPROJECT.read_text(encoding="utf-8")
    deps_match = re.search(
        r"(?ms)^dependencies\s*=\s*\[(.*?)\]\s*\n\n\[project",
        text,
    )
    assert deps_match, "base dependencies block not found"
    body = deps_match.group(1).lower()
    assert "bertopic" not in body
    assert "hdbscan" not in body
    assert "umap-learn" not in body
    extra = " ".join(_parse_optional_extra("bertopic")).lower()
    assert "bertopic" in extra
    assert "hdbscan" in extra
    assert "umap-learn" in extra
