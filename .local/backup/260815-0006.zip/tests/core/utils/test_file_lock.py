"""
Tests for file locking mechanisms.

This module tests lock acquisition, release, timeout, and concurrency handling.
"""

import time
from unittest.mock import patch, mock_open


import pytest

from transcriptx.core.utils.file_lock import (
    FileLock,
    LockAcquisitionError,
    cleanup_stale_locks,
    _ERRNO_EROFS,
)


class TestFileLock:
    """Tests for FileLock class."""

    def test_initialization(self, tmp_path):
        """Test FileLock initialization."""
        test_file = tmp_path / "test.txt"
        lock = FileLock(test_file, timeout=60, blocking=True)

        assert lock.file_path == test_file
        assert lock.timeout == 60
        assert lock.blocking is True
        assert lock.lock_file == test_file.with_suffix(".txt.lock")
        assert lock.acquired is False

    def test_context_manager_usage(self, tmp_path):
        """Test FileLock as context manager."""
        test_file = tmp_path / "test.txt"

        with (
            patch("transcriptx.core.utils.file_lock.fcntl") as mock_fcntl,
            patch("builtins.open", mock_open()),
        ):
            mock_fcntl.LOCK_EX = 2
            mock_fcntl.LOCK_NB = 4
            mock_fcntl.LOCK_UN = 8

            with FileLock(test_file) as lock:
                assert lock.acquired is True

            # Lock should be released
            assert lock.acquired is False

    def test_acquire_lock_success(self, tmp_path):
        """Test successful lock acquisition."""
        test_file = tmp_path / "test.txt"
        lock = FileLock(test_file, blocking=False)

        with (
            patch("transcriptx.core.utils.file_lock.fcntl") as mock_fcntl,
            patch("builtins.open", mock_open()),
        ):
            mock_fcntl.LOCK_EX = 2
            mock_fcntl.LOCK_NB = 4

            result = lock.acquire()

            assert result is True
            assert lock.acquired is True

    def test_acquire_lock_fails_when_locked(self, tmp_path):
        """Test that lock acquisition fails when file is already locked."""
        test_file = tmp_path / "test.txt"
        lock = FileLock(test_file, blocking=False)

        with (
            patch("transcriptx.core.utils.file_lock.fcntl") as mock_fcntl,
            patch("builtins.open", mock_open()),
        ):
            mock_fcntl.LOCK_EX = 2
            mock_fcntl.LOCK_NB = 4
            mock_fcntl.flock.side_effect = IOError("Resource temporarily unavailable")

            result = lock.acquire()

            assert result is False
            assert lock.acquired is False

    def test_acquire_lock_timeout(self, tmp_path):
        """Test that lock acquisition times out."""
        test_file = tmp_path / "test.txt"
        lock = FileLock(test_file, timeout=0.1, blocking=True)

        with (
            patch("transcriptx.core.utils.file_lock.fcntl") as mock_fcntl,
            patch("builtins.open", mock_open()),
            patch("time.sleep") as mock_sleep,
        ):
            mock_fcntl.LOCK_EX = 2
            mock_fcntl.LOCK_NB = 4
            mock_fcntl.flock.side_effect = IOError("Resource temporarily unavailable")

            result = lock.acquire()

            assert result is False
            assert lock.acquired is False
            # Should have attempted to sleep
            assert mock_sleep.called

    def test_context_manager_raises_on_blocking_timeout(self, tmp_path):
        """Blocking context managers must not proceed unlocked on timeout."""
        test_file = tmp_path / "test.txt"

        with (
            patch("transcriptx.core.utils.file_lock.fcntl") as mock_fcntl,
            patch("builtins.open", mock_open()),
            patch("time.sleep"),
        ):
            mock_fcntl.LOCK_EX = 2
            mock_fcntl.LOCK_NB = 4
            mock_fcntl.flock.side_effect = IOError("Resource temporarily unavailable")

            with pytest.raises(LockAcquisitionError):
                with FileLock(test_file, timeout=0.1, blocking=True):
                    pass

    def test_nested_locks_same_path_are_reentrant(self, tmp_path):
        """Same-thread nested locks on one path must not self-deadlock."""
        test_file = tmp_path / "nested.txt"
        test_file.write_text("x", encoding="utf-8")

        with FileLock(test_file, timeout=2) as outer:
            assert outer.acquired is True
            with FileLock(test_file, timeout=2) as inner:
                assert inner.acquired is True
                assert inner._reentrant is True
            assert outer.acquired is True
        assert outer.acquired is False
        assert not test_file.with_suffix(".txt.lock").exists()

    def test_release_lock(self, tmp_path):
        """Test lock release."""
        test_file = tmp_path / "test.txt"
        lock = FileLock(test_file)

        with (
            patch("transcriptx.core.utils.file_lock.fcntl") as mock_fcntl,
            patch("builtins.open", mock_open()),
        ):
            mock_fcntl.LOCK_EX = 2
            mock_fcntl.LOCK_NB = 4
            mock_fcntl.LOCK_UN = 8

            # Acquire lock first
            lock.acquire()
            assert lock.acquired is True

            # Release lock
            lock.release()

            assert lock.acquired is False
            mock_fcntl.flock.assert_called()

    def test_release_when_not_acquired(self, tmp_path):
        """Test that release does nothing when lock not acquired."""
        test_file = tmp_path / "test.txt"
        lock = FileLock(test_file)

        # Release without acquiring
        lock.release()

        assert lock.acquired is False

    def test_is_locked_returns_false_when_not_locked(self, tmp_path):
        """Test that is_locked returns False when file is not locked."""
        test_file = tmp_path / "test.txt"
        lock = FileLock(test_file)

        with (
            patch("transcriptx.core.utils.file_lock.fcntl") as mock_fcntl,
            patch("builtins.open", mock_open()),
        ):
            mock_fcntl.LOCK_EX = 2
            mock_fcntl.LOCK_NB = 4
            mock_fcntl.LOCK_UN = 8

            result = lock.is_locked()

            assert result is False

    def test_is_locked_returns_true_when_locked(self, tmp_path):
        """Test that is_locked returns True when file is locked."""
        test_file = tmp_path / "test.txt"
        lock = FileLock(test_file)

        with (
            patch("transcriptx.core.utils.file_lock.fcntl") as mock_fcntl,
            patch("builtins.open", mock_open()),
        ):
            mock_fcntl.LOCK_EX = 2
            mock_fcntl.LOCK_NB = 4
            mock_fcntl.flock.side_effect = IOError("Resource temporarily unavailable")

            result = lock.is_locked()

            assert result is True

    def test_handles_windows_locking(self, tmp_path):
        """Test Windows-specific locking behavior."""
        test_file = tmp_path / "test.txt"
        lock = FileLock(test_file)

        with (
            patch("transcriptx.core.utils.file_lock.WINDOWS", True),
            patch("transcriptx.core.utils.file_lock.msvcrt") as mock_msvcrt,
            patch("builtins.open", mock_open()),
        ):
            mock_msvcrt.LK_NBLCK = 1
            mock_msvcrt.LK_UNLCK = 2

            result = lock.acquire()

            # Should attempt Windows locking
            assert mock_msvcrt.locking.called or result is not None

    def test_handles_locking_not_available(self, tmp_path):
        """Test behavior when locking is not available."""
        test_file = tmp_path / "test.txt"
        lock = FileLock(test_file)

        with (
            patch("transcriptx.core.utils.file_lock.WINDOWS", False),
            patch("transcriptx.core.utils.file_lock.fcntl", None),
        ):
            result = lock.acquire()

            assert result is False

    def test_creates_lock_file_directory(self, tmp_path):
        """Test that lock file directory is created."""
        test_file = tmp_path / "subdir" / "test.txt"
        lock = FileLock(test_file)

        with (
            patch("transcriptx.core.utils.file_lock.fcntl") as mock_fcntl,
            patch("builtins.open", mock_open()),
        ):
            mock_fcntl.LOCK_EX = 2
            mock_fcntl.LOCK_NB = 4

            lock.acquire()

            # Directory should be created
            assert test_file.parent.exists() or lock.lock_file.parent.exists()


class TestCleanupStaleLocks:
    """Tests for cleanup_stale_locks function."""

    def test_removes_stale_lock(self, tmp_path):
        """Test that stale lock file is removed."""
        lock_file = tmp_path / "test.txt.lock"
        lock_file.write_text("lock content")

        # Make file old
        old_time = time.time() - 4000  # More than 1 hour
        lock_file.touch()
        import os

        os.utime(lock_file, (old_time, old_time))

        cleanup_stale_locks(lock_file, max_age_seconds=3600)

        assert not lock_file.exists()

    def test_keeps_recent_lock(self, tmp_path):
        """Test that recent lock file is kept."""
        lock_file = tmp_path / "test.txt.lock"
        lock_file.write_text("lock content")
        lock_file.touch()  # Recent modification time

        cleanup_stale_locks(lock_file, max_age_seconds=3600)

        assert lock_file.exists()

    def test_handles_nonexistent_lock(self, tmp_path):
        """Test that function handles nonexistent lock file."""
        lock_file = tmp_path / "nonexistent.lock"

        # Should not raise error
        cleanup_stale_locks(lock_file)

    def test_handles_cleanup_errors(self, tmp_path):
        """Test that cleanup errors are handled."""
        lock_file = tmp_path / "test.txt.lock"
        lock_file.write_text("lock content")

        with patch("pathlib.Path.unlink") as mock_unlink:
            mock_unlink.side_effect = OSError("Permission denied")

            # Should not raise error
            cleanup_stale_locks(lock_file, max_age_seconds=0)


class TestFileLockErofsAndAcquireErrors:
    """0.3.8 FileLock edges: read-only FS fallback and acquire failure cleanup."""

    def test_acquire_falls_back_to_temp_lock_on_erofs(self, tmp_path, monkeypatch):
        test_file = tmp_path / "ro" / "doc.json"
        test_file.parent.mkdir()
        test_file.write_text("{}", encoding="utf-8")
        lock = FileLock(test_file, blocking=False)
        calls = {"n": 0}
        real = FileLock._acquire_at_path

        def _acquire(self, lock_path):
            calls["n"] += 1
            if calls["n"] == 1:
                raise OSError(_ERRNO_EROFS, "Read-only file system")
            return real(self, lock_path)

        monkeypatch.setattr(FileLock, "_acquire_at_path", _acquire)

        assert lock.acquire() is True
        assert calls["n"] == 2
        assert "transcriptx_locks" in str(lock.lock_file)
        lock.release()

    def test_acquire_at_path_exception_closes_fd(self, tmp_path):
        test_file = tmp_path / "doc.json"
        test_file.write_text("{}", encoding="utf-8")
        lock = FileLock(test_file, blocking=False)
        closed = {"n": 0}

        class _Fd:
            def fileno(self):
                return 3

            def close(self):
                closed["n"] += 1

        with (
            patch("transcriptx.core.utils.file_lock.fcntl") as mock_fcntl,
            patch("builtins.open", return_value=_Fd()),
        ):
            mock_fcntl.LOCK_EX = 2
            mock_fcntl.LOCK_NB = 4
            mock_fcntl.flock.side_effect = RuntimeError("unexpected flock failure")
            assert lock.acquire() is False
            assert closed["n"] == 1
            assert lock.lock_fd is None
            assert lock.acquired is False
