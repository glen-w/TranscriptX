"""
Tests for configuration management.

This module tests config loading, validation, defaults, and environment variable handling.
"""

import json
from unittest.mock import patch

import pytest

from transcriptx.core.utils import nlp_runtime
from transcriptx.core.utils.config import (
    TranscriptXConfig,
    AnalysisConfig,
    OutputConfig,
    AudioPreprocessingConfig,
    load_config,
    get_config,
    set_config,
)
from transcriptx.core.utils.config.config_errors import ConfigLoadError


class TestAnalysisConfig:
    """Tests for AnalysisConfig dataclass."""

    def test_default_values(self):
        """Test that default values are set correctly."""
        config = AnalysisConfig()

        assert config.sentiment_window_size == 10
        assert config.sentiment_min_confidence == 0.1
        assert config.emotion_min_confidence == 0.3
        assert isinstance(config.ner_labels, list)
        assert len(config.ner_labels) > 0

    def test_custom_values(self):
        """Test that custom values can be set via setattr (delegated init=False)."""
        config = AnalysisConfig()
        config.sentiment_window_size = 20
        config.sentiment_min_confidence = 0.5

        assert config.sentiment_window_size == 20
        assert config.sentiment_min_confidence == 0.5

    def test_ner_labels_default(self):
        """Test that NER labels have default values."""
        config = AnalysisConfig()

        assert "PERSON" in config.ner_labels
        assert "ORG" in config.ner_labels


class TestOutputConfig:
    """Tests for OutputConfig dataclass."""

    def test_default_values(self):
        """Test that default values are set correctly."""
        config = OutputConfig()

        assert config.base_output_dir is not None
        assert config.default_audio_folder is not None
        assert config.default_transcript_folder is not None


class TestAudioPreprocessingConfig:
    """Tests for AudioPreprocessingConfig dataclass."""

    def test_default_values(self):
        """Test that default values are set correctly."""
        config = AudioPreprocessingConfig()

        assert config.preprocessing_mode == "selected"
        assert config.convert_to_mono == "auto"
        assert config.downsample == "auto"
        assert config.target_sample_rate == 16000
        assert config.skip_if_already_compliant is True
        assert config.normalize_mode == "auto"
        assert config.target_lufs == -18.0
        assert config.limiter_enabled is True
        assert config.limiter_peak_db == -1.0
        assert config.denoise_mode == "suggest"
        assert config.denoise_strength == "medium"
        assert config.highpass_mode == "suggest"
        assert config.highpass_cutoff == 80
        assert config.lowpass_mode == "off"
        assert config.lowpass_cutoff == 8000
        assert config.bandpass_mode == "off"
        assert config.bandpass_low == 300
        assert config.bandpass_high == 3400

    def test_custom_values(self):
        """Test that custom values can be set."""
        config = AudioPreprocessingConfig()
        config.preprocessing_mode = "auto"
        config.convert_to_mono = "off"
        config.target_sample_rate = 22050
        config.normalize_mode = "suggest"
        config.target_lufs = -16.0
        config.denoise_mode = "auto"
        config.denoise_strength = "high"

        assert config.preprocessing_mode == "auto"
        assert config.convert_to_mono == "off"
        assert config.target_sample_rate == 22050
        assert config.normalize_mode == "suggest"
        assert config.target_lufs == -16.0
        assert config.denoise_mode == "auto"
        assert config.denoise_strength == "high"

    def test_three_mode_values(self):
        """Test that all preprocessing steps support three modes."""
        config = AudioPreprocessingConfig()
        config.convert_to_mono = "suggest"
        config.downsample = "off"
        config.normalize_mode = "auto"
        config.denoise_mode = "suggest"
        config.highpass_mode = "auto"
        config.lowpass_mode = "suggest"
        config.bandpass_mode = "off"

        assert config.convert_to_mono == "suggest"
        assert config.downsample == "off"
        assert config.normalize_mode == "auto"
        assert config.denoise_mode == "suggest"
        assert config.highpass_mode == "auto"
        assert config.lowpass_mode == "suggest"
        assert config.bandpass_mode == "off"

    def test_global_mode_override(self):
        """Test that global preprocessing_mode can override per-step settings."""
        config = AudioPreprocessingConfig()
        config.preprocessing_mode = "auto"
        config.convert_to_mono = "suggest"
        config.downsample = "off"
        config.normalize_mode = "suggest"

        # Global mode should be set
        assert config.preprocessing_mode == "auto"
        # Per-step modes are still stored, but will be overridden by global mode
        assert config.convert_to_mono == "suggest"
        assert config.downsample == "off"
        assert config.normalize_mode == "suggest"


class TestTranscriptXConfigClass:
    """Tests for TranscriptXConfig."""

    def test_initialization(self):
        """Test TranscriptXConfig initialization."""
        config = TranscriptXConfig()

        assert isinstance(config.analysis, AnalysisConfig)
        assert isinstance(config.output, OutputConfig)
        assert isinstance(config.audio_preprocessing, AudioPreprocessingConfig)

    def test_custom_analysis_config(self):
        """Test that custom analysis config can be provided."""
        analysis_config = AnalysisConfig()
        analysis_config.sentiment_window_size = 15
        config = TranscriptXConfig()
        config.analysis = analysis_config

        assert config.analysis.sentiment_window_size == 15

    def test_init_with_config_file_loads_settings(self, tmp_path):
        """TranscriptXConfig(config_file=path) loads analysis/output from JSON."""
        config_file = tmp_path / "config.json"
        config_file.write_text(
            json.dumps(
                {
                    "analysis": {"sentiment_window_size": 33},
                    "output": {},
                    "logging": {},
                }
            )
        )
        config = TranscriptXConfig(config_file=str(config_file))
        assert config.analysis.sentiment_window_size == 33

    def test_install_profile_full_sets_core_mode_false(self, tmp_path):
        """When install_profile file contains 'full', core_mode is False."""
        (tmp_path / "install_profile").write_text("full")
        with patch(
            "transcriptx.core.utils.paths.CONFIG_DIR",
            tmp_path,
        ):
            config = TranscriptXConfig()
        assert config.core_mode is False

    def test_install_profile_core_or_empty_keeps_core_mode_true(self, tmp_path):
        """When install_profile is 'core' or absent, core_mode stays True."""
        (tmp_path / "install_profile").write_text("core")
        with patch(
            "transcriptx.core.utils.paths.CONFIG_DIR",
            tmp_path,
        ):
            config = TranscriptXConfig()
        assert config.core_mode is True


class TestLoadConfig:
    """Tests for load_config function."""

    def test_loads_from_file(self, tmp_path):
        """Test loading configuration from file."""
        config_file = tmp_path / "config.json"
        config_data = {
            "analysis": {"sentiment_window_size": 20, "sentiment_min_confidence": 0.5}
        }
        config_file.write_text(json.dumps(config_data))

        config = load_config(str(config_file))

        assert config.analysis.sentiment_window_size == 20
        assert config.analysis.sentiment_min_confidence == 0.5

    def test_uses_defaults_when_file_not_exists(self, tmp_path):
        """Test that defaults are used when file doesn't exist."""
        config_file = tmp_path / "nonexistent.json"

        config = load_config(str(config_file))

        # Should use defaults
        assert config.analysis.sentiment_window_size == 10

    def test_handles_invalid_json(self, tmp_path):
        """Test that invalid JSON is handled."""
        config_file = tmp_path / "config.json"
        config_file.write_text("invalid json")

        # Should use defaults or raise error
        with pytest.raises((json.JSONDecodeError, ValueError)):
            load_config(str(config_file))

    def test_environment_variable_overrides(self, tmp_path, monkeypatch):
        """Test that environment variables override file settings."""
        config_file = tmp_path / "config.json"
        config_data = {"analysis": {"sentiment_window_size": 20}}
        config_file.write_text(json.dumps(config_data))

        monkeypatch.setenv("TRANSCRIPTX_SENTIMENT_WINDOW_SIZE", "30")

        config = load_config(str(config_file))

        # Environment variable should override
        assert config.analysis.sentiment_window_size == 30

    def test_loads_audio_preprocessing_from_file(self, tmp_path):
        """Test loading audio preprocessing configuration from file."""
        config_file = tmp_path / "config.json"
        config_data = {
            "audio_preprocessing": {
                "convert_to_mono": "off",
                "target_sample_rate": 22050,
                "normalize_mode": "suggest",
                "denoise_mode": "auto",
                "denoise_strength": "high",
            }
        }
        config_file.write_text(json.dumps(config_data))

        config = load_config(str(config_file))

        assert config.audio_preprocessing.convert_to_mono == "off"
        assert config.audio_preprocessing.target_sample_rate == 22050
        assert config.audio_preprocessing.normalize_mode == "suggest"
        assert config.audio_preprocessing.denoise_mode == "auto"
        assert config.audio_preprocessing.denoise_strength == "high"

    def test_rejects_legacy_audio_preprocessing_keys(self, tmp_path):
        """Legacy bool-style keys are rejected with a migration-directional error."""
        config_file = tmp_path / "config.json"
        config_data = {
            "audio_preprocessing": {
                "normalize_enabled": True,
                "target_sample_rate": 22050,
            }
        }
        config_file.write_text(json.dumps(config_data))

        with pytest.raises(ConfigLoadError) as exc_info:
            load_config(str(config_file))
        assert exc_info.value.code == "unsupported_legacy_shape"
        assert "normalize_mode" in str(exc_info.value)

    def test_audio_preprocessing_environment_variable_overrides(
        self, tmp_path, monkeypatch
    ):
        """Test that environment variables override audio preprocessing file settings."""
        config_file = tmp_path / "config.json"
        config_data = {"audio_preprocessing": {"target_sample_rate": 16000}}
        config_file.write_text(json.dumps(config_data))

        monkeypatch.setenv("TRANSCRIPTX_AUDIO_TARGET_SAMPLE_RATE", "22050")
        monkeypatch.setenv("TRANSCRIPTX_AUDIO_DENOISE_MODE", "auto")

        config = load_config(str(config_file))

        # Environment variable should override
        assert config.audio_preprocessing.target_sample_rate == 22050
        assert config.audio_preprocessing.denoise_mode == "auto"

    def test_rejects_legacy_audio_enabled_environment_variables(
        self, tmp_path, monkeypatch
    ):
        """TRANSCRIPTX_AUDIO_*_ENABLED env vars are rejected."""
        config_file = tmp_path / "config.json"
        config_data = {"audio_preprocessing": {"target_sample_rate": 16000}}
        config_file.write_text(json.dumps(config_data))

        monkeypatch.setenv("TRANSCRIPTX_AUDIO_DENOISE_ENABLED", "true")

        with pytest.raises(ConfigLoadError) as exc_info:
            load_config(str(config_file))
        assert exc_info.value.code == "unsupported_legacy_shape"
        assert "TRANSCRIPTX_AUDIO_DENOISE_ENABLED" in str(exc_info.value)


class TestGetConfig:
    """Tests for get_config function."""

    def test_returns_singleton_instance(self):
        """Test that get_config returns singleton instance."""
        with patch("transcriptx.core.utils.config._global_config", None):
            config1 = get_config()
            config2 = get_config()

            # Should be same instance
            assert config1 is config2

    def test_uses_default_config_when_none(self):
        """Test that default config is used when none exists."""
        with patch("transcriptx.core.utils.config._global_config", None):
            config = get_config()

            assert isinstance(config, TranscriptXConfig)
            assert isinstance(config.analysis, AnalysisConfig)
            assert isinstance(config.audio_preprocessing, AudioPreprocessingConfig)


class TestSaveConfig:
    """Tests for save_config function."""

    def test_saves_config_to_file(self, tmp_path):
        """Test that config is saved to file."""
        tmp_path / "config.json"
        config = TranscriptXConfig()
        config.analysis.sentiment_window_size = 25

        # Config is saved through the config object's save method or via load_config
        # For now, just test that we can create and set config
        set_config(config)

        # Config is set globally, not necessarily saved to file
        retrieved = get_config()
        assert isinstance(retrieved, TranscriptXConfig)

    def test_creates_directory_if_needed(self, tmp_path):
        """Test that directory is created if it doesn't exist."""
        tmp_path / "subdir" / "config.json"
        config = TranscriptXConfig()

        # Config is saved through the config object's save method or via load_config
        # For now, just test that we can create and set config
        set_config(config)

        # Config is set globally
        retrieved = get_config()
        assert isinstance(retrieved, TranscriptXConfig)

    def test_preserves_all_settings(self, tmp_path):
        """Test that all settings are preserved when saving."""
        config_file = tmp_path / "config.json"
        config = TranscriptXConfig()
        config.analysis.sentiment_window_size = 30
        config.analysis.emotion_min_confidence = 0.4

        # Save config to file using the save_to_file method
        config.save_to_file(str(config_file))

        # Load it back and verify
        loaded_config = load_config(str(config_file))

        assert loaded_config.analysis.sentiment_window_size == 30
        assert loaded_config.analysis.emotion_min_confidence == 0.4

    def test_preserves_audio_preprocessing_settings(self, tmp_path):
        """Test that audio preprocessing settings are preserved when saving."""
        config_file = tmp_path / "config.json"
        config = TranscriptXConfig()
        config.audio_preprocessing.preprocessing_mode = "auto"
        config.audio_preprocessing.target_sample_rate = 22050
        config.audio_preprocessing.denoise_mode = "auto"
        config.audio_preprocessing.denoise_strength = "high"
        config.audio_preprocessing.normalize_mode = "suggest"

        # Save config to file
        config.save_to_file(str(config_file))

        # Load it back and verify
        loaded_config = load_config(str(config_file))

        assert loaded_config.audio_preprocessing.preprocessing_mode == "auto"
        assert loaded_config.audio_preprocessing.target_sample_rate == 22050
        assert loaded_config.audio_preprocessing.denoise_mode == "auto"
        assert loaded_config.audio_preprocessing.denoise_strength == "high"
        assert loaded_config.audio_preprocessing.normalize_mode == "suggest"


class TestConfigRejectsLegacySections:
    """Unsupported config sections raise ConfigLoadError."""

    def test_config_rejects_transcription_section(self, tmp_path):
        """Config files with a 'transcription' section are rejected."""
        config_file = tmp_path / "config.json"
        config_data = {
            "transcription": {
                "model_name": "large-v2",
                "compute_type": "float16",
                "language": "en",
                "batch_size": 16,
                "diarize": True,
            },
            "analysis": {"sentiment_window_size": 10},
        }
        config_file.write_text(json.dumps(config_data))

        with pytest.raises(ConfigLoadError) as exc_info:
            load_config(str(config_file))
        assert exc_info.value.code == "unknown_section"
        assert "transcription" in str(exc_info.value)


class TestDownloadPolicy:
    """Tests for downloads-on-by-default behavior."""

    def test_downloads_enabled_by_default(self, monkeypatch):
        """Test downloads are enabled unless explicitly disabled."""
        monkeypatch.delenv("TRANSCRIPTX_DISABLE_DOWNLOADS", raising=False)
        assert nlp_runtime._downloads_disabled() is False

    def test_downloads_disabled_with_opt_out(self, monkeypatch):
        """Test downloads can be disabled explicitly via env var."""
        monkeypatch.setenv("TRANSCRIPTX_DISABLE_DOWNLOADS", "1")
        assert nlp_runtime._downloads_disabled() is True

    def test_spacy_download_disabled_by_default_unset(self, monkeypatch):
        """TRANSCRIPTX_DISABLE_SPACY_DOWNLOAD unset means allow (spaCy auto-download)."""
        monkeypatch.delenv("TRANSCRIPTX_DISABLE_SPACY_DOWNLOAD", raising=False)
        assert nlp_runtime._spacy_download_disabled() is False

    def test_spacy_download_disabled_when_set(self, monkeypatch):
        """TRANSCRIPTX_DISABLE_SPACY_DOWNLOAD=1 means do not auto-download spaCy."""
        monkeypatch.setenv("TRANSCRIPTX_DISABLE_SPACY_DOWNLOAD", "1")
        assert nlp_runtime._spacy_download_disabled() is True

    def test_disable_spacy_download_skips_download(self, monkeypatch):
        """When TRANSCRIPTX_DISABLE_SPACY_DOWNLOAD=1, _ensure_spacy_model returns without calling download."""
        monkeypatch.setenv("TRANSCRIPTX_DISABLE_SPACY_DOWNLOAD", "1")
        monkeypatch.setattr(nlp_runtime, "_core_mode", lambda: False)

        class _FakeSpacy:
            def load(self, _model):
                raise OSError("missing model")

            class cli:
                @staticmethod
                def download(_model):
                    raise AssertionError("download should not be called")

        monkeypatch.setattr(nlp_runtime, "_import_spacy", lambda: _FakeSpacy())
        nlp_runtime._ensure_spacy_model("en_core_web_sm")

    def test_disable_spacy_download_ensure_raises(self, monkeypatch):
        """When TRANSCRIPTX_DISABLE_SPACY_DOWNLOAD=1, ensure_spacy_model raises with manual install message."""
        monkeypatch.setenv("TRANSCRIPTX_DISABLE_SPACY_DOWNLOAD", "1")
        monkeypatch.setattr(nlp_runtime, "_core_mode", lambda: False)

        class _FakeSpacy:
            def load(self, _model):
                raise OSError("missing model")

            class cli:
                @staticmethod
                def download(_model):
                    raise AssertionError("download should not be called")

        monkeypatch.setattr(nlp_runtime, "_import_spacy", lambda: _FakeSpacy())
        with pytest.raises(OSError) as exc_info:
            nlp_runtime.ensure_spacy_model("en_core_web_sm")
        assert "TRANSCRIPTX_DISABLE_SPACY_DOWNLOAD" in str(exc_info.value)
        assert "python -m spacy download" in str(exc_info.value)

    def test_default_unset_attempts_spacy_download(self, monkeypatch):
        """Default (unset) with non-core mode: attempt download (mock spacy.cli.download, assert called)."""
        monkeypatch.delenv("TRANSCRIPTX_DISABLE_SPACY_DOWNLOAD", raising=False)
        monkeypatch.setattr(nlp_runtime, "_core_mode", lambda: False)
        called = {"download": False}

        class _FakeSpacy:
            def load(self, _model):
                raise OSError("missing model")

            class cli:
                @staticmethod
                def download(_model):
                    called["download"] = True

        monkeypatch.setattr(nlp_runtime, "_import_spacy", lambda: _FakeSpacy())
        nlp_runtime._ensure_spacy_model("en_core_web_sm")
        assert called["download"] is True
